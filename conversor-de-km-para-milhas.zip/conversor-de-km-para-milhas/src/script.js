console.log("Conversor de Km para Milhas");

var Km = prompt("Digite o KM a Ser convertido: ");
console.log(Km);

var Milhas = 0.621371;

var ress = 0;

ress = Km * Milhas

console.log("Seu Valor em Milhas é: " + ress);
